

<?php echo $__env->make('users.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
    <h2>Edit License</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('user.licenses.update', $license->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    
        <div class="form-group">
            <label for="product">Select Product</label>
            <select name="product_id" id="product" class="form-control" required>
                <option value="">-- Select Product --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" <?php echo e($license->product_id == $product->id ? 'selected' : ''); ?> data-name="<?php echo e($product->product_name); ?>">
                        <?php echo e($product->product_id); ?> - <?php echo e($product->product_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    
        <!-- Add a hidden input for the product_name -->
        <input type="hidden" name="product_name" id="product_name" value="<?php echo e($license->product_name); ?>" required>
    
        <div class="form-group mt-3">
            <label for="license-codes">License Codes</label>
            <input type="text" name="license_codes" id="license-codes" class="form-control" value="<?php echo e($license->license_codes); ?>" required>
        </div>
    
        <div class="form-group mt-3">
            <label for="license-use-limit">License Use Limit</label>
            <input type="number" name="license_use_limit" id="license-use-limit" class="form-control" value="<?php echo e($license->license_use_limit == -1 ? '' : $license->license_use_limit); ?>">
            <small class="text-muted">Leave empty for unlimited use (-1).</small>
        </div>
    
        <div class="form-group mt-3">
            <label for="license-expiration-date">License Expiration Date</label>
            <input type="date" name="license_expiration_date" id="license-expiration-date" class="form-control" value="<?php echo e($license->license_expiration_date); ?>">
            <small class="text-muted">Leave empty for no expiration.</small>
        </div>
    
        <button type="submit" class="btn btn-success mt-3">Update License</button>
    </form>
</div>

<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\testing\veryy\resources\views/users/licenses/edit.blade.php ENDPATH**/ ?>