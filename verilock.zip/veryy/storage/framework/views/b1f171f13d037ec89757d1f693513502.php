

<?php echo $__env->make('admin.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <h3 class="text-center mb-4">User Management</h3>
<br>
    <div class="d-flex justify-content-between mb-4">
        <h5>User Management</h5>
        <a href="<?php echo e(route('admin.user.register')); ?>" class="btn btn-success" style="width: 20%"><i class="fas fa-box"></i>  Register Users</a>
    </div>
<?php if($Redeemuser->isEmpty()): ?>
        <p class="text-center">No users found. Click "Register User" to add a new one.</p>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Roles</th>
                    <th>Redeem Code</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Redeemuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Redeemuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Redeemuser->id); ?></td>
                        <td><?php echo e($Redeemuser->name); ?></td>
                        <td><?php echo e($Redeemuser->email); ?></td>
                        <td><?php echo e($Redeemuser->roles); ?></td>
                        <td><?php echo e($Redeemuser->redeem_code); ?></td>
                        <td><?php echo e($Redeemuser->created_at); ?></td>
                        <td><?php echo e($Redeemuser->updated_at); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('admin.usermanage.edit', $Redeemuser->id)); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <form action="<?php echo e(route('admin.user.destroy', $Redeemuser->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"
                                        onclick="return confirm('Are you sure you want to delete this user?');" style="background: red"><i class="fas fa-trash"></i> Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u200235715/domains/freeazio.com/public_html/verilock/resources/views/admin/usermanage/index.blade.php ENDPATH**/ ?>