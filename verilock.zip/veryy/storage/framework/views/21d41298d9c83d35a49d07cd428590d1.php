
<!DOCTYPE html>
<!-- Coding by CodingNepal | www.codingnepalweb.com-->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Login and Registration Form in HTML & CSS | CodingLab </title>
    <link rel="stylesheet" href="style.css">
    <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
    <style>
      body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #7d2ae8;
  padding: 30px;
}
.container {
  position: relative;
  max-width: 1000px;
  width: 100%;
  background: #fff;
  padding: 40px 30px;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
  perspective: 2700px;
}
    </style>
<body>

  <div class="container">
    
    <input type="checkbox" id="flip">
    <div class="cover">
      <div class="front">
        <img src="images/frontImg.jpg" alt="" style="background: black">
        <div class="text">
          <span class="text-1">Every new friend is a <br> new adventure</span>
          <span class="text-2">Let's get connected</span>
        </div>
      </div>
      <div class="back">
        <img class="backImg" src="images/backImg.jpg" alt="" style="background:black">
        <div class="text">
          <span class="text-1">Complete miles of journey <br> with one step</span>
          <span class="text-2">Let's get started</span>
        </div>
      </div>
    </div>
    <div class="forms">
        <div class="form-content">
          <div class="login-form">
            <div class="title">Login</div>
            <form action="<?php echo e(route('user.login')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="input-boxes">
                  <div class="input-box">
                      <i class="fas fa-envelope"></i>
                      <input type="email" name="email" placeholder="Enter your email" required>
                  </div>
                  <div class="input-box">
                      <i class="fas fa-lock"></i>
                      <input type="password" name="password" placeholder="Enter your password" required>
                  </div>
                  <div class="text"><a href="#">Forgot password?</a></div>
                  <div class="button input-box">
                      <input type="submit" value="Submit">
                  </div>
                  <?php if(session('error')): ?>
                  <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>Error!</strong> <?php echo e(session('error')); ?>

                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                  <?php endif; ?>
                  <div class="text sign-up-text">Don't have an account? <label for="flip">Signup now</label></div>
              </div>
          </form>
          
      </div>
        <div class="signup-form">
          <div class="title">Signup</div>
          <form action="<?php echo e(route('register')); ?>" method="POST">
            <?php echo csrf_field(); ?> <!-- CSRF token for Laravel security -->
            <div class="input-boxes">
                <div class="input-box">
                    <i class="fas fa-user"></i>
                    <input type="text" name="name" placeholder="Enter your name" required>
                </div>
                <div class="input-box">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="input-box">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Enter your password" required>
                </div>
                <div class="input-box">
                    <i class="fas fa-tag"></i>
                    <input type="text" name="redeem_code" placeholder="Enter your redeem code" required>
                </div>
                <div class="button input-box">
                    <input type="submit" value="Submit">
                </div>
                <div class="text sign-up-text">
                    Already have an account? <label for="flip">Login now</label>
                </div>
            </div>
        </form>        
    </div>
    </div>
    </div>
  </div>
</body>
</html>
<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Verilock\resources\views/users/login.blade.php ENDPATH**/ ?>