

<?php $__env->startSection('content'); ?>
<div class="login-container d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-lg" style="width: 100%; max-width: 400px;">
        <div class="card-body">
            <h3 class="text-center mb-4">VeriLock Login</h3>
            
            <!-- Form for login -->
            <form action="<?php echo e(route('admin.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <!-- Email Input -->
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" id="email" placeholder="Email" required>
                </div>

                <!-- Password Input -->
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>

            <!-- Forgot Password Link -->
            <p class="text-center mt-3">
                <a href="#">Forgot password?</a>
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\Manas Coding IMP\EAZIO PROJECT\Applications\verilock10\resources\views/admin/login.blade.php ENDPATH**/ ?>