

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">VeriLock Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('products')); ?>">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('licenses.index')); ?>">Licenses</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Profile</a>
                </li>
                <li class="nav-item">
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link btn btn-link text-white" style="border: none; background: none;">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="row">
        <!-- Dashboard Card: Total Registered Products -->
        <div class="col-md-4 mb-4">
            <div class="card shadow text-center">
                <div class="card-header bg-primary text-white">
                    <h5>Total Registered Products</h5>
                </div>
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($productCount); ?></h3>
                    <p class="card-text">Products currently registered.</p>
                </div>
            </div>
        </div>
        <!-- Dashboard Card: Total Licenses -->
        <div class="col-md-4 mb-4">
            <div class="card shadow text-center">
                <div class="card-header bg-warning text-black">
                    <h5>Total Licenses</h5>
                </div>
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($licenseShow->count()); ?></h3>
                    <p class="card-text">Licenses currently in use.</p>
                </div>
            </div>
        </div>
        <!-- Dashboard Card: Active Licenses -->
        <div class="col-md-4 mb-4">
            <div class="card shadow text-center">
                <div class="card-header bg-success text-white">
                    <h5>Active Licenses</h5>
                </div>
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($licenseShow->where('active', true)->count()); ?></h3>
                    <p class="card-text">Active licenses currently in use.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-12">
            <!-- License Table -->
            <div class="card shadow">
                <div class="card-header bg-dark text-white text-center">
                    <h5>Licenses Information</h5>
                </div>
                <div class="card-body">
                    <?php if($licenseShow->isNotEmpty()): ?>
                        <table class="table table-bordered table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>User Email</th>
                                    <th>License Code</th>
                                    <th>Product ID</th>
                                    <th>Domain</th>
                                    <th>Active</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $licenseShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($license->id); ?></td>
                                        <td><?php echo e($license->user_email); ?></td>
                                        <td><?php echo e($license->user_license); ?></td>
                                        <td><?php echo e($license->product_id); ?></td>
                                        <td><?php echo e($license->domain); ?></td>
                                        <td><?php echo e($license->active ? 'Yes' : 'No'); ?></td>
                                        <td><?php echo e($license->created_at->format('d M Y, h:i A')); ?></td>
                                        <td><?php echo e($license->updated_at->format('d M Y, h:i A')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center">No Licenses Found</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\Manas Coding IMP\EAZIO PROJECT\Applications\public_html\testing\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>