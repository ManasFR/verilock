

<?php echo $__env->make('admin.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
    
    <h2>Licenses</h2>
    <div class="text-end mb-4">
        <a href="<?php echo e(route('licenses.create')); ?>" class="btn btn-primary" style="width: 20%"><i class="fas fa-key"></i> Create Licenses</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    <?php endif; ?>

    <?php if($licenses->isEmpty()): ?>
        <p>No licenses available.</p>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>License Codes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($license->id); ?></td>
                        <td><?php echo e($license->product_name); ?></td>
                        <td>
                            <ul id="license-codes-<?php echo e($license->id); ?>">
                                <?php $__currentLoopData = explode(',', $license->license_codes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index < 10): ?>
                                        <li><?php echo e($code); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        
                            <button id="view-more-<?php echo e($license->id); ?>" class="btn btn-link view-more-btn" 
                                    style="color:white; width:25%; text-decoration:none; border-radius:5%;">
                                <i class="fas fa-chevron-down"></i> View More
                            </button>
                            <button id="view-less-<?php echo e($license->id); ?>" class="btn btn-link view-less-btn" 
                                    style="display: none; color:white; width:25%; text-decoration:none; border-radius:5%;">
                                <i class="fas fa-chevron-up"></i> View Less
                            </button>
                        
                            <ul id="all-license-codes-<?php echo e($license->id); ?>" style="display: none;">
                                <?php $__currentLoopData = explode(',', $license->license_codes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($index >= 10): ?>
                                        <li><?php echo e($code); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        
                        <td>
                            <div class="d-flex align-items-center">
                                <a href="<?php echo e(route('admin.licenses.edit', $license->id)); ?>" class="btn mx-2" style="background-color: #ffc107; color: #212529; flex-fill me-2; width:50%">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('licenses.destroy', $license->id)); ?>" method="POST" class="flex-fill">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn" style="background-color: #dc3545; color: white;" onclick="return confirm('Are you sure you want to delete this license?')"><i class="fas fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </td>                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>            
        </table>
    <?php endif; ?>
</div>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/37a/1/17d000c812/public_html/verilock/resources/views/admin/licenses/index.blade.php ENDPATH**/ ?>