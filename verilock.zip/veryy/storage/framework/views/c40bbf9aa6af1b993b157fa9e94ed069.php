
<?php echo $__env->make('admin.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <h3 class="text-center mb-4">Redeem Codes Management</h3>

    <div class="d-flex justify-content-between mb-4">
        <h5>Redeem Codes</h5>
        <a href="<?php echo e(route('redeemcreate')); ?>" class="btn btn-success" style="width: 20%"><i class="fas fa-tag"></i> Create Redeem Codes</a>
    </div>

    <!-- Bootstrap Pills -->
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <?php $__currentLoopData = $redeemCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item" role="presentation">
                <button 
                    class="nav-link <?php echo e($index === 0 ? 'active' : ''); ?>" 
                    id="pills-<?php echo e($code->id); ?>-tab" 
                    data-bs-toggle="pill" 
                    data-bs-target="#pills-<?php echo e($code->id); ?>" 
                    type="button" 
                    role="tab" 
                    aria-controls="pills-<?php echo e($code->id); ?>" 
                    aria-selected="<?php echo e($index === 0 ? 'true' : 'false'); ?>">
                    <?php echo e($code->company_name); ?>

                </button>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="tab-content" id="pills-tabContent">
        <?php $__currentLoopData = $redeemCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div 
                class="tab-pane fade <?php echo e($index === 0 ? 'show active' : ''); ?>" 
                id="pills-<?php echo e($code->id); ?>" 
                role="tabpanel" 
                aria-labelledby="pills-<?php echo e($code->id); ?>-tab">
                <h5 class="mt-3">Redeem Codes for <?php echo e($code->company_name); ?></h5>
                <ul class="list-group">
                    <?php $__currentLoopData = explode(',', $code->redeem_codes); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redeemCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item"><?php echo e($redeemCode); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u200235715/domains/freeazio.com/public_html/verilock/resources/views/admin/redeemcodes/index.blade.php ENDPATH**/ ?>