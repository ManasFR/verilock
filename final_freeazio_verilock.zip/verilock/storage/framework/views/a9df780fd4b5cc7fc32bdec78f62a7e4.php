
<?php echo $__env->make('users.navbar.lost-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>



<div class="container mt-5">
    <h1>Lost Password</h1>
    <form method="POST" action="<?php echo e(route('sendResetPassword')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Enter your email address:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Send Reset Password</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\Manas Coding IMP\EAZIO PROJECT\Applications\verilock\public_html\verilock\resources\views/users/lost-password.blade.php ENDPATH**/ ?>