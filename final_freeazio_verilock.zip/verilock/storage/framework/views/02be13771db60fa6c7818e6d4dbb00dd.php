
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register and Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 700px !important;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        .error {
            color: red;
            font-size: 14px;
        }
        .success {
            color: green;
            font-size: 14px;
        }
        .link {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body style="background:#021414;">
    <div class="start-container" style="margin-top:5rem; padding:10px 20px; text-align:center;">
        <img src="https://freeazio.com/wp-content/uploads/2025/01/logo-white-300x300.png" style="height:190px; margin-top:-6rem;">
    <h2 style="font-weight:bold; color:white;">Welcome to Verilock</h2>
        <p style="color:white;">Register Yourself with verilock and protect your work.</p>
        </div>
    <div class="container">
        
        <!-- Display success or error message -->
        <?php if(session('error')): ?>
            <div class="error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <!-- Register Form -->
        <h2>Register</h2>
        <form action="<?php echo e(route('user.register')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="name" placeholder="Full Name" required value="<?php echo e(old('name')); ?>">
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
            </div>
            <div class="form-group">
                <input type="text" name="redeem_code" placeholder="Redeem Code" value="<?php echo e(old('redeem_code')); ?>" required>
            </div>
            <button type="submit">Register</button>
        </form>

        <div class="link">
            <p>Already have an account? <a href="#" id="show-login">Login here</a></p>
        </div>

        <!-- Login Form -->
        <h2 id="login-form-title" style="display: none;">Login</h2>
        <form action="<?php echo e(route('user.login')); ?>" method="POST" id="login-form" style="display: none;">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            
            <button type="submit">Login</button>
        </form>

        <div class="link" id="register-link" style="display: none;">
            <p>Don't have an account? <a href="#" id="show-register">Register here</a></p>
        </div>
    </div>

    <script>
        document.getElementById('show-login').addEventListener('click', function() {
            document.getElementById('login-form').style.display = 'block';
            document.getElementById('login-form-title').style.display = 'block';
            document.querySelector('form').style.display = 'none';
            document.getElementById('register-link').style.display = 'none';
        });

        document.getElementById('show-register').addEventListener('click', function() {
            document.querySelector('form').style.display = 'block';
            document.getElementById('register-link').style.display = 'block';
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('login-form-title').style.display = 'none';
        });
    </script>
</body>
</html>

<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u200235715/domains/freeazio.com/public_html/verilock/resources/views/users/login.blade.php ENDPATH**/ ?>