


<div class="container mt-5">
    <h2>Validate License</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(isset($validLicense)): ?>
        <div class="alert alert-info">
            <strong>Existing License Details:</strong><br>
            <p><strong>Email:</strong> <?php echo e($validLicense->user_email); ?></p>
            <p><strong>Product:</strong> <?php echo e($validLicense->product->product_name ?? 'N/A'); ?></p>
            <p><strong>License Code:</strong> <?php echo e($validLicense->user_license); ?></p>
            <p><strong>Domain:</strong> <?php echo e($validLicense->domain); ?></p>
            <p><strong>Status:</strong> <?php echo e($validLicense->active ? 'Active' : 'Inactive'); ?></p>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('licenses.validate')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="user_email">Email Address</label>
            <input type="email" name="user_email" id="user_email" class="form-control" 
                   value="<?php echo e($validLicense->user_email ?? old('user_email')); ?>" required>
        </div>

        <div class="form-group mt-3">
            <label for="product_name">Product Name</label>
            <input type="text" name="product_name" id="product_name" class="form-control" 
                   value="<?php echo e($validLicense->product->product_name ?? old('product_name')); ?>" required>
        </div>

        <div class="form-group mt-3">
            <label for="user_license">License Code</label>
            <input type="text" name="user_license" id="user_license" class="form-control" 
                   value="<?php echo e($validLicense->user_license ?? old('user_license')); ?>" required>
        </div>

        <input type="hidden" name="domain" value="<?php echo e($validLicense->domain ?? $_SERVER['HTTP_HOST']); ?>">

        <button type="submit" class="btn btn-primary mt-3">Validate License</button>
    </form>
    <div class="domain-container">
        <h1 class="mb-4">Licenses for Domain: <?php echo e($currentDomain); ?></h1>
        
            <?php if($validLicenses->isEmpty()): ?>
                <div class="alert alert-warning">
                    No licenses found for this domain (<?php echo e($currentDomain); ?>).
                </div>
            <?php else: ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>License Code</th>
                            <th>Domain</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $validLicenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($license->user_license); ?></td>
                                <td><?php echo e($license->domain); ?></td>
                                <td>
                                    <?php if($license->active): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($license->active): ?>
                                        <form action="<?php echo e(route('deactivate.license')); ?>" method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="license_id" value="<?php echo e($license->id); ?>">
                                            <button class="btn btn-danger btn-sm" type="submit">Deactivate</button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>Already Inactive</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
</div>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\testing\veryy\resources\views/admin/valid_license.blade.php ENDPATH**/ ?>