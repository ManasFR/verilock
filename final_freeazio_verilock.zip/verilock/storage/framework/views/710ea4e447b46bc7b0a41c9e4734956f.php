 <!-- Assuming you're using a layout -->
<?php echo $__env->make('admin.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<br>
    <div class="container">
        <h2>Edit User</h2>
        <br>
        <form action="<?php echo e(route('admin.usermanage.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Enter new password">
            </div>

            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u200235715/domains/freeazio.com/public_html/verilock/resources/views/admin/usermanage/edit.blade.php ENDPATH**/ ?>