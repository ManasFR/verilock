
<?php echo $__env->make('users.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="container mt-5">
    <div class="row mt-4">
        <div class="col-md-12">
            <!-- License Table -->
            <div class="card-info shadow">
                <div class="card-header bg-primary text-white text-center" style="padding:10px; border-radius:10px;">
                    <h3>Licenses Activations</h3>
                    <a style="background:green; margin-bottom:1rem;" href="<?php echo e(route('user.export.licenses')); ?>" class="btn btn-light">Export Licenses</a>
                    
                    <input type="text" id="searchInput" placeholder="Search by Email or License Code" class="form-control">
                </div>
                <br>

                <div class="card-body">
                    <?php if($licenseShow->isNotEmpty()): ?>
                    <table class="table table-bordered table-hover" id="licenseTable">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>User Email</th>
                                    <th>License Code</th>
                                    <th>Product ID</th>
                                    <th>Domain</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $licenseShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($license->id); ?></td>
                                        <td><?php echo e($license->user_email); ?></td>
                                        <td><?php echo e($license->user_license); ?></td>
                                        <td><?php echo e($license->product->product_name ?? 'Unknown'); ?></td>
                                        <td><?php echo e($license->domain); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($license->active ? 'bg-success' : 'bg-danger'); ?> text-white">
                                                <?php echo e($license->active ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        </td>
                                        
                                        <td>
                                            <?php if($license->active): ?>
                                                <!-- Deactivate Button -->
                                                <form action="<?php echo e(route('deactivate.license')); ?>" method="POST" style="display:inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="license_id" value="<?php echo e($license->id); ?>">
                                                    <button class="btn btn-danger btn-sm" type="submit" style="background: red"><i class="fas fa-times-circle"></i> Deactivate</button>
                                                </form>
                                            <?php else: ?>
                                                <!-- Activate Button -->
                                                <form action="<?php echo e(route('activate.license')); ?>" method="POST" style="display:inline-block;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="license_id" value="<?php echo e($license->id); ?>">
                                                    <button class="btn btn-success btn-sm" type="submit" style="background: green"><i class="fas fa-check-circle"></i> Activate</button>
                                                </form>
                                            <?php endif; ?>
                                        </td>                                        
                                        
                                        <td><?php echo e($license->created_at->format('d M Y, h:i A')); ?></td>
                                        <td><?php echo e($license->updated_at->format('d M Y, h:i A')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-center">No Licenses Found</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const searchInput = document.getElementById("searchInput");
            const licenseTable = document.getElementById("licenseTable");
    
            // Search by User Email or License Code
            searchInput.addEventListener("keyup", function () {
                let filter = searchInput.value.toLowerCase();
                let rows = licenseTable.getElementsByTagName("tr");
    
                for (let i = 1; i < rows.length; i++) { // Start from 1 to skip table header
                    let emailCell = rows[i].getElementsByTagName("td")[1]; // User Email is in column index 1
                    let licenseCodeCell = rows[i].getElementsByTagName("td")[2]; // License Code is in column index 2
                    
                    if (emailCell && licenseCodeCell) {
                        let emailText = emailCell.textContent.toLowerCase();
                        let licenseCodeText = licenseCodeCell.textContent.toLowerCase();
                        
                        // Show row if it matches User Email or License Code
                        if (emailText.includes(filter) || licenseCodeText.includes(filter)) {
                            rows[i].style.display = "";
                        } else {
                            rows[i].style.display = "none";
                        }
                    }
                }
            });
        });
    </script>
    
<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\Manas Coding IMP\EAZIO PROJECT\Applications\verilock\public_html\verilock\resources\views/users/licenses/activations.blade.php ENDPATH**/ ?>