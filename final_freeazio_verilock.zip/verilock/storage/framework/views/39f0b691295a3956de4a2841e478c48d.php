

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">VeriLock Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('product-show')); ?>">Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('licenses.index')); ?>">Licenses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('apigenerate')); ?>">Generate Script</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('redeemcode')); ?>">Redeem Codes</a>
                </li>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">Profile</a>
                </li>
                <li class="nav-item">
                    <!-- Logout Button -->
                    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link btn btn-link" style="border: none; background: none; padding: 0;">Logout</button>
                    </form>
                </li>
                
            </ul>
        </div>
    </div>
</nav>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Verilock\resources\views/admin/navbar/header.blade.php ENDPATH**/ ?>