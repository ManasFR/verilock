
<?php echo $__env->make('users.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<!-- users/user-update/profile.blade.php -->

<div class="text-center mt-5">
<h1>Update Profile</h1>
<p>Please update your email and password below.</p>
</div>

<div class="container">
<form action="<?php echo e(route('profile.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" name="name" id="name" value="<?php echo e(old('name', $name)); ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" name="email" id="email" value="<?php echo e(old('email', $email)); ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">New Password</label>
        <input type="password" name="password" id="password" class="form-control" placeholder="Leave blank if not changing">
    </div>

    <div class="mb-3">
        <label for="password_confirmation" class="form-label">Confirm Password</label>
        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="Leave blank if not changing">
    </div>

    <button type="submit" class="btn btn-primary">Update Profile</button>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sites/37a/1/17d000c812/public_html/verilock/resources/views/users/user-update/profile.blade.php ENDPATH**/ ?>