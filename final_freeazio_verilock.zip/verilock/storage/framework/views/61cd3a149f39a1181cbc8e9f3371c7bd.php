
<?php echo $__env->make('admin.navbar.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Generate License Validation Script</h1>
    <button id="generate-script" class="btn btn-primary">Generate API Script</button>

    <div id="generated-script" style="margin-top: 20px;">
        <!-- Generated script will appear here -->
    </div>
</div>

<script>
    document.getElementById('generate-script').addEventListener('click', async function () {
        const responseDiv = document.getElementById('generated-script');
        try {
            const response = await fetch('<?php echo e(route('generate.api.script')); ?>', {
                method: 'GET',
            });

            const result = await response.json();
            if (result.success) {
                responseDiv.innerHTML = `<pre>${result.script}</pre>`;
            } else {
                responseDiv.textContent = 'Failed to generate the script.';
            }
        } catch (error) {
            responseDiv.textContent = 'Error: Unable to generate the script.';
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\OneDrive\Desktop\Manas Coding IMP\EAZIO PROJECT\Applications\public_html\testing\resources\views/admin/apigenerate/apigenerate.blade.php ENDPATH**/ ?>